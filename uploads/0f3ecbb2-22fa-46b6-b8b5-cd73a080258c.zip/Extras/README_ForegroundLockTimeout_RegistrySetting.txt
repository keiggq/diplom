Earlier versions of Process Tamer set the registry value 
	HKEY_CURRENT_USER\Control Panel\Desktop\ForegroundLockTimeout to 0
As described by the Microsoft bulletin for more information:
	http://support.microsoft.com/?kbid=886217
In order to fix a problem where popup windows would lose foreground focus.

Because ProcessTamer now uses baloons to report information, it no longer
 sets this value, and you will find in this directory two registry files,
 which when double clicked will let you set this registry value to wither
 the default value of 200000 or the value described in the windows tweak
 and employed by the original ProcessTamer, 0.

Most people won't care about this or notice any difference, but we are
 providing them for the sake of completeness.